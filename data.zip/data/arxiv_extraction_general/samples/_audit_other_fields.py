"""
Per-row precision audit for the four non-harness benchmark-level metadata
fields: n_shot, temperature, prompt_template, decoding_strategy.

Ground truth was built via WebFetch on each paper's HTML (asking the LLM
to read the paper text and report per-benchmark values). For each row in
the WITH v2 CSV, compare the pipeline's value (in
generation_config.generation_args + additional_details) against the
ground-truth value. Skip rows where the ground truth is "unknown" — the
paper itself doesn't say, so we can't audit those.
"""

import csv
import json
import os
from collections import defaultdict

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
WITH_PATH  = os.path.join(SCRIPT_DIR, "annotation_eval_harness_WITH_v2.csv")
DATA_ROOT  = os.path.join(SCRIPT_DIR, "..", "llm")

# Ground truth per (paper, benchmark). Values "unknown" mean the paper
# doesn't state, so we cannot audit. Treated as null and skipped.
GROUND_TRUTH = {
    # ── Aya 23 ──────────────────────────────────────────────────────────────
    ("Aya_23__Open_Weight_Releases_to_Further_Multilingual_Progress", "XCOPA"):                          dict(n_shot=0,  prompt_template="unknown"),
    ("Aya_23__Open_Weight_Releases_to_Further_Multilingual_Progress", "XStoryCloze"):                    dict(n_shot=0),
    ("Aya_23__Open_Weight_Releases_to_Further_Multilingual_Progress", "XWinograd"):                      dict(n_shot=0),
    ("Aya_23__Open_Weight_Releases_to_Further_Multilingual_Progress", "Multilingual MMLU"):              dict(n_shot=5),
    ("Aya_23__Open_Weight_Releases_to_Further_Multilingual_Progress", "MGSM"):                           dict(n_shot=5,  prompt_template="chain-of-thought"),
    ("Aya_23__Open_Weight_Releases_to_Further_Multilingual_Progress", "FLORES-200"):                     dict(n_shot=0),
    ("Aya_23__Open_Weight_Releases_to_Further_Multilingual_Progress", "XLSum"):                          dict(n_shot=0),
    ("Aya_23__Open_Weight_Releases_to_Further_Multilingual_Progress", "Dolly Open-Ended (GPT-4 judge)"): dict(n_shot=0,  prompt_template="instruction-formatted"),

    # ── Sheared LLaMA ──────────────────────────────────────────────────────
    ("Sheared_LLaMA__Accelerating_LM_Pre-training_via_Structured_Pruning", "ARC-C"):       dict(n_shot=25),
    ("Sheared_LLaMA__Accelerating_LM_Pre-training_via_Structured_Pruning", "ARC-E"):       dict(n_shot=0),
    ("Sheared_LLaMA__Accelerating_LM_Pre-training_via_Structured_Pruning", "BoolQ"):       dict(n_shot=32),
    ("Sheared_LLaMA__Accelerating_LM_Pre-training_via_Structured_Pruning", "HellaSwag"):   dict(n_shot=10),
    ("Sheared_LLaMA__Accelerating_LM_Pre-training_via_Structured_Pruning", "LAMBADA"):     dict(n_shot=0),
    ("Sheared_LLaMA__Accelerating_LM_Pre-training_via_Structured_Pruning", "LogiQA"):      dict(n_shot=0),
    ("Sheared_LLaMA__Accelerating_LM_Pre-training_via_Structured_Pruning", "MMLU"):        dict(n_shot=5),
    ("Sheared_LLaMA__Accelerating_LM_Pre-training_via_Structured_Pruning", "NQ"):          dict(n_shot=32),
    ("Sheared_LLaMA__Accelerating_LM_Pre-training_via_Structured_Pruning", "PIQA"):        dict(n_shot=0),
    ("Sheared_LLaMA__Accelerating_LM_Pre-training_via_Structured_Pruning", "SciQ"):        dict(n_shot=0),
    ("Sheared_LLaMA__Accelerating_LM_Pre-training_via_Structured_Pruning", "WinoGrande"):  dict(n_shot=0),

    # ── Llemma ─────────────────────────────────────────────────────────────
    ("Llemma__An_Open_Language_Model_for_Mathematics", "GSM8k"):                  dict(n_shot=8, prompt_template="chain-of-thought", decoding_strategy="greedy"),
    ("Llemma__An_Open_Language_Model_for_Mathematics", "GSM8k-majority@100"):     dict(n_shot=8, temperature=0.6, prompt_template="chain-of-thought", decoding_strategy="nucleus sampling"),
    ("Llemma__An_Open_Language_Model_for_Mathematics", "GSM8k-majority@256"):     dict(n_shot=8, temperature=0.6, prompt_template="chain-of-thought", decoding_strategy="nucleus sampling"),
    ("Llemma__An_Open_Language_Model_for_Mathematics", "GSM8k+Python"):           dict(prompt_template="Python tool use", decoding_strategy="greedy"),
    ("Llemma__An_Open_Language_Model_for_Mathematics", "MATH"):                   dict(n_shot=4, prompt_template="chain-of-thought", decoding_strategy="greedy"),
    ("Llemma__An_Open_Language_Model_for_Mathematics", "MATH-majority@256"):      dict(n_shot=4, temperature=0.6, prompt_template="chain-of-thought", decoding_strategy="nucleus sampling"),
    ("Llemma__An_Open_Language_Model_for_Mathematics", "MATH+Python"):            dict(prompt_template="Python tool use", decoding_strategy="greedy"),
    ("Llemma__An_Open_Language_Model_for_Mathematics", "MMLU-STEM"):              dict(n_shot=4, prompt_template="chain-of-thought", decoding_strategy="greedy"),
    ("Llemma__An_Open_Language_Model_for_Mathematics", "MMLU-STEM-majority@16"):  dict(n_shot=4, temperature=0.3, prompt_template="chain-of-thought", decoding_strategy="nucleus sampling"),
    ("Llemma__An_Open_Language_Model_for_Mathematics", "OCWCourses"):             dict(n_shot=4, prompt_template="chain-of-thought", decoding_strategy="greedy"),
    ("Llemma__An_Open_Language_Model_for_Mathematics", "OCWCourses-majority@100"):dict(n_shot=4, temperature=0.6, prompt_template="chain-of-thought", decoding_strategy="nucleus sampling"),
    ("Llemma__An_Open_Language_Model_for_Mathematics", "SAT"):                    dict(n_shot=4, prompt_template="chain-of-thought", decoding_strategy="greedy"),
    ("Llemma__An_Open_Language_Model_for_Mathematics", "SAT-majority@16"):        dict(n_shot=4, temperature=0.3, prompt_template="chain-of-thought", decoding_strategy="nucleus sampling"),
    ("Llemma__An_Open_Language_Model_for_Mathematics", "miniF2F-Isabelle"):       dict(n_shot=11, prompt_template="informal-to-formal", decoding_strategy="greedy"),
    ("Llemma__An_Open_Language_Model_for_Mathematics", "miniF2F-Lean"):           dict(n_shot=3,  prompt_template="formal-to-formal", decoding_strategy="best first search"),

    # ── Nemotron-4 15B ─────────────────────────────────────────────────────
    ("Nemotron-4_15B_Technical_Report", "ARC-c"):           dict(n_shot=0),
    ("Nemotron-4_15B_Technical_Report", "ARC-e"):           dict(n_shot=0),
    ("Nemotron-4_15B_Technical_Report", "BBH"):             dict(n_shot=3),
    ("Nemotron-4_15B_Technical_Report", "FLORES-101"):      dict(n_shot=8),
    ("Nemotron-4_15B_Technical_Report", "GSM8K"):           dict(n_shot=8, prompt_template="chain-of-thought"),
    ("Nemotron-4_15B_Technical_Report", "Hellaswag"):       dict(n_shot=0),
    ("Nemotron-4_15B_Technical_Report", "HumanEval"):       dict(n_shot=0),
    ("Nemotron-4_15B_Technical_Report", "MBPP"):            dict(n_shot=3),
    ("Nemotron-4_15B_Technical_Report", "MGSM"):            dict(n_shot=8, prompt_template="chain-of-thought"),
    ("Nemotron-4_15B_Technical_Report", "MMLU"):            dict(n_shot=5),
    ("Nemotron-4_15B_Technical_Report", "MultiPL-E"):       dict(n_shot=0),
    ("Nemotron-4_15B_Technical_Report", "PIQA"):            dict(n_shot=0),
    ("Nemotron-4_15B_Technical_Report", "SIQA"):            dict(n_shot=0),
    ("Nemotron-4_15B_Technical_Report", "TyDiQA-GoldP"):    dict(n_shot=1),
    ("Nemotron-4_15B_Technical_Report", "Winogrande"):      dict(n_shot=0),
    ("Nemotron-4_15B_Technical_Report", "XCOPA (0-shot)"):  dict(n_shot=0),
    ("Nemotron-4_15B_Technical_Report", "XCOPA (4-shot)"):  dict(n_shot=4),
}

# BLOOM applied at the benchmark-FAMILY level (Flores-101 / WMT14 are all
# translation; SuperGLUE is the 7 SuperGLUE tasks; etc.). We attach a group
# match via prefix.
BLOOM_GROUPS = {
    "SuperGLUE":           dict(n_shot=0,  prompt_template="multiple prompts per task (promptsource)", decoding_strategy="log-likelihood ranking"),
    "WMT14":               dict(n_shot=0,  decoding_strategy="greedy"),
    "Flores-101":          dict(n_shot=0,  decoding_strategy="greedy"),
    "HumanEval":           dict(n_shot=0),
    "DiaBLa":              dict(n_shot=1,  decoding_strategy="greedy"),
    "WikiLingua":          dict(n_shot=1,  decoding_strategy="greedy"),
    # MASSIVE / STS22 / Multilingual Probing: nothing specified
}

FIELDS = ("n_shot", "temperature", "prompt_template", "decoding_strategy")


def bloom_lookup(benchmark):
    for prefix, gt in BLOOM_GROUPS.items():
        if benchmark.startswith(prefix):
            return gt
    return None


def get_ground_truth(paper, benchmark):
    if paper.startswith("BLOOM"):
        return bloom_lookup(benchmark) or {}
    return GROUND_TRUTH.get((paper, benchmark), {})


def _norm_str(s):
    if s is None:
        return None
    s = str(s).strip().lower()
    if s in ("", "none", "null", "unknown", "n/a"):
        return None
    return s


def _norm_int(s):
    if s is None or s == "":
        return None
    try:
        return int(float(s))
    except (ValueError, TypeError):
        return None


def _norm_float(s):
    if s is None or s == "":
        return None
    try:
        return float(s)
    except (ValueError, TypeError):
        return None


def _match(field, pipeline_value, gt_value):
    """Return True if pipeline matches ground truth, False if mismatch."""
    if field == "n_shot":
        p, g = _norm_int(pipeline_value), _norm_int(gt_value)
    elif field == "temperature":
        p, g = _norm_float(pipeline_value), _norm_float(gt_value)
    else:
        p, g = _norm_str(pipeline_value), _norm_str(gt_value)
        if p and g:
            # accept canonical equivalents
            if "chain" in p and "chain" in g:
                return True
            if "greedy" in p and "greedy" in g:
                return True
            if "nucleus" in p and "nucleus" in g:
                return True
    return p == g and p is not None


def read_pipeline_value(json_path, field):
    """Pull a benchmark-level field from the EEE JSON file."""
    with open(json_path, "r", encoding="utf-8") as f:
        d = json.load(f)
    ev = d.get("evaluation_results", [{}])[0]
    gc = ev.get("generation_config", {}) or {}
    gen_args = gc.get("generation_args", {}) or {}
    extra    = gc.get("additional_details", {}) or {}
    if field == "n_shot":       return gen_args.get("shots")
    if field == "temperature":  return gen_args.get("temperature")
    if field == "prompt_template": return gen_args.get("prompt_template")
    if field == "decoding_strategy": return extra.get("decoding_strategy")
    return None


def main():
    for enc in ("utf-8-sig", "cp1252"):
        try:
            with open(WITH_PATH, "r", encoding=enc) as f:
                rows = list(csv.DictReader(f))
            break
        except UnicodeDecodeError:
            continue

    # Per-paper x per-field: [auditable, true]
    stats = defaultdict(lambda: defaultdict(lambda: [0, 0]))
    overall = defaultdict(lambda: [0, 0])

    for r in rows:
        pf  = r["paper_folder"]
        bm  = r["benchmark"]
        gt  = get_ground_truth(pf, bm)
        if not gt:
            continue
        json_path = os.path.join(SCRIPT_DIR, "..", r["json_file"])
        if not os.path.exists(json_path):
            continue
        for field in FIELDS:
            gt_val = gt.get(field)
            if gt_val is None or gt_val == "unknown":
                continue  # can't audit
            pl_val = read_pipeline_value(json_path, field)
            ok = _match(field, pl_val, gt_val)
            stats[pf][field][0] += 1
            overall[field][0]   += 1
            if ok:
                stats[pf][field][1] += 1
                overall[field][1]   += 1

    # ── Report ─────────────────────────────────────────────────────────────
    print("=" * 100)
    print(f"{'paper':<48}  {'n_shot':>14}  {'temp':>10}  {'prompt':>10}  {'decoding':>10}")
    print("-" * 100)
    for pf in sorted(stats.keys()):
        row = [pf[:46]]
        for field in FIELDS:
            n, t = stats[pf][field][0], stats[pf][field][1]
            if n == 0:
                cell = "n/a"
            else:
                cell = f"{t}/{n}={100*t/n:.0f}%"
            row.append(cell)
        print(f"  {row[0]:<48}  {row[1]:>14}  {row[2]:>10}  {row[3]:>10}  {row[4]:>10}")
    print("-" * 100)
    row = ["OVERALL"]
    for field in FIELDS:
        n, t = overall[field]
        row.append(f"{t}/{n}={100*t/max(n,1):.1f}%" if n else "n/a")
    print(f"  {row[0]:<48}  {row[1]:>14}  {row[2]:>10}  {row[3]:>10}  {row[4]:>10}")


if __name__ == "__main__":
    main()
