"""
Fill annotation, annotator_notes, and correct columns under STRICT
per-(paper, benchmark) rules.

For each WITH paper, the paper itself only uses the named harness for a
specific subset of its benchmarks. The pipeline blanket-labels every row
with that harness even when the benchmark was actually run with a
different tool (judge models, proof assistants, machine-translation
pipelines, etc.). Strict rubric: each row is TRUE only if the pipeline's
eval_library label correctly describes the tool used for THAT specific
benchmark.

WITHOUT papers are paper-level: every row gets "unknown" -> TRUE.

Verified 2026-05-23 via WebFetch reads of each paper's HTML.
"""

import csv
import os

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
WITH_PATH    = os.path.join(SCRIPT_DIR, "annotation_eval_harness_WITH_v2.csv")
WITHOUT_PATH = os.path.join(SCRIPT_DIR, "annotation_eval_harness_WITHOUT_v2.csv")

# ── Per-(paper, benchmark) classifications for the 5 WITH papers ────────────
# Each paper entry has:
#   harness_benchmarks   : set of benchmark names where the paper explicitly
#                          ran the named harness
#   harness_annotation   : verbatim harness name (annotation value for those rows)
#   non_harness_note     : template note for rows NOT in harness_benchmarks
#   harness_note         : template note for rows in harness_benchmarks
#   fork_mismatch        : if True, even harness_benchmarks rows are FALSE
#                          (e.g., BLOOM: pipeline's "lm-evaluation-harness"
#                          does not equal the paper's "Prompted Language
#                          Model Evaluation Harness")
PAPER_INFO = {
    "BLOOM__A_176B-Parameter_Open-Access_Multilingual_Language_Model": dict(
        harness_annotation = "Prompted Language Model Evaluation Harness",
        # BLOOM §4.1.2 says its Prompted Language Model Evaluation Harness
        # "extends EleutherAI's Language Model Evaluation Harness ... by
        # integrating it with the promptsource library". promptsource ships
        # prompt templates for the SuperGLUE tasks; BLOOM uses its renamed
        # fork to evaluate on those tasks. Other benchmarks (WMT14, Flores-101,
        # HumanEval, MASSIVE, STS22, Multilingual Probing) are run via
        # separate pipelines and stay out of the set.
        harness_benchmarks = {
            "SuperGLUE-Ax-b", "SuperGLUE-Ax-g", "SuperGLUE-BoolQ",
            "SuperGLUE-CB", "SuperGLUE-RTE", "SuperGLUE-WSC", "SuperGLUE-WiC",
        },
        fork_mismatch = True,
        harness_note = (
            "Section 4.1.2 (Infrastructure): Prompted Language Model "
            "Evaluation Harness named for SuperGLUE tasks."
        ),
        non_harness_note = (
            "Section 4 (Evaluation): benchmark not in the SuperGLUE group "
            "the Prompted-... Harness covers (separate MT / code / MTEB / "
            "probing pipeline)."
        ),
    ),
    "Llemma__An_Open_Language_Model_for_Mathematics": dict(
        harness_annotation = "Language Model Evaluation Harness",
        harness_benchmarks = {
            "GSM8k", "MATH", "MMLU-STEM", "OCWCourses", "SAT",
        },
        fork_mismatch = False,
        harness_note = (
            "Section 3.1 (Chain-of-thought results): Language Model "
            "Evaluation Harness fork named for open-access model evaluations."
        ),
        non_harness_note = (
            "Section 3.2 / 3.3 (Tool use / Theorem proving): not run via the "
            "lm-eval-harness fork (majority voting / Python / Isabelle / Lean)."
        ),
    ),
    "Sheared_LLaMA__Accelerating_LM_Pre-training_via_Structured_Pruning": dict(
        harness_annotation = "lm-evaluation-harness",
        harness_benchmarks = {
            "ARC-C", "ARC-E", "BoolQ", "HellaSwag", "LAMBADA", "LogiQA",
            "MMLU", "NQ", "PIQA", "SciQ", "WinoGrande",
        },
        fork_mismatch = False,
        harness_note = (
            "Section 3.1 (Setup, Evaluation): lm-evaluation-harness named "
            "for the downstream-task suite."
        ),
        non_harness_note = (
            "Section 4.2 / Appendix F.3: system metric or separate code/math "
            "evaluation, not via lm-evaluation-harness."
        ),
    ),
    "Aya_23__Open_Weight_Releases_to_Further_Multilingual_Progress": dict(
        harness_annotation = "eval-harness",
        harness_benchmarks = {
            "XCOPA", "XStoryCloze", "XWinograd",
            "Multilingual MMLU", "MGSM",
        },
        fork_mismatch = False,
        harness_note = (
            "Section 4 (Multilingual Evaluation): eval-harness named for "
            "discriminative tasks, multilingual MMLU, and MGSM."
        ),
        non_harness_note = (
            "Section 4 (Generative / Preference Evaluation): not run via "
            "eval-harness (MT pipeline, GPT-4 judge, or human eval)."
        ),
    ),
    "Nemotron-4_15B_Technical_Report": dict(
        harness_annotation = "LM-Evaluation Harness",
        # Section 3 intro: "In all evaluations, we adhere to the standardized
        # task setup and share the exact settings used." Section 3.1: "We use
        # the LM-Evaluation Harness (Gao et al., 2021) to evaluate Nemotron-4
        # 15B across all aforementioned tasks." The "aforementioned tasks"
        # covers all 5 evaluation categories listed in the §3 intro:
        # Commonsense Reasoning, Popular Aggregated Benchmarks (MMLU, BBH),
        # Math (GSM8K), Code (HumanEval, MBPP, MultiPL-E), and Multilingual
        # (XCOPA, FLORES-101, MGSM, TyDiQA).
        harness_benchmarks = {
            # Commonsense Reasoning
            "ARC-c", "ARC-e", "Hellaswag", "PIQA", "SIQA", "Winogrande",
            # Popular Aggregated Benchmarks
            "MMLU", "BBH",
            # Math
            "GSM8K",
            # Code
            "HumanEval", "MBPP", "MultiPL-E",
            # Multilingual
            "XCOPA (0-shot)", "XCOPA (4-shot)",
            "FLORES-101", "MGSM", "TyDiQA-GoldP",
        },
        fork_mismatch = False,
        harness_note = (
            "Section 3.1: LM-Evaluation Harness named for \"all aforementioned "
            "tasks\" -- the full set of benchmarks in §3 across all 5 "
            "categories (Commonsense, MMLU/BBH, Math, Code, Multilingual)."
        ),
        non_harness_note = (
            "Section 3: benchmark not listed in any §3 evaluation category "
            "(unexpected — investigate before trusting this row)."
        ),
    ),
}

# WITHOUT-pool papers: paper-level (single annotation per paper).
# Note text is the "where in paper" prefix only — the TRUE/FALSE verdict is
# appended per-row by fill_without().
PAPER_ANNOT_WITHOUT = {
    "Llama_2__Open_Foundation_and_Fine-Tuned_Chat_Models": (
        "unknown",
        "arXiv:2307.06435 is a survey paper, not the Llama 2 model paper; "
        "no own evaluations.",
    ),
    "Code_Llama__Open_Foundation_Models_for_Code": (
        "unknown",
        "Section 3 (Results): no harness named for HumanEval/MBPP/APPS runs.",
    ),
    "Mamba__Linear-Time_Sequence_Modeling_with_Selective_State_Spaces": (
        "unknown",
        "Section 4.2.2 (Downstream Evaluations): no harness named.",
    ),
    "Reka_Core__Flash__and_Edge__Powerful_Multimodal_Language_Models": (
        "unknown",
        "Section 2.3.1 (Inference and serving): \"custom inference stack\"; "
        "no public harness named.",
    ),
    "Jamba__Hybrid_Transformer-Mamba_Language_Model": (
        "unknown",
        "Section 5 (Evaluation) / Section 6 (Ablations): no harness named "
        "for own runs.",
    ),
}


def read_csv(path):
    for enc in ("utf-8-sig", "cp1252"):
        try:
            with open(path, "r", encoding=enc, newline="") as f:
                return list(csv.DictReader(f))
        except UnicodeDecodeError:
            continue
    raise RuntimeError(f"cannot decode {path}")


def _is_blank(s):
    return not s or s.strip().lower() in {"", "unknown", "none", "null"}


def _norm(s):
    """Normalise harness names for matching: lowercase, collapse separators."""
    return "".join(c for c in (s or "").lower() if c.isalnum())


# Canonical equivalence groups: all of these names refer to the EleutherAI
# lm-evaluation-harness family. A pipeline label and an annotation are
# considered "the same library" if they fall into the same group.
_CANONICAL_GROUPS = [
    {_norm(x) for x in (
        "lm-evaluation-harness",
        "lm-eval-harness",
        "lm_eval_harness",
        "lm-eval",
        "lm eval",
        "eval-harness",
        "eval harness",
        "Language Model Evaluation Harness",
        "LM-Evaluation Harness",
        "LM Evaluation Harness",
    )},
]


def _same_library(a, b):
    """True if a and b name the same library after normalisation."""
    na, nb = _norm(a), _norm(b)
    if not na or not nb:
        return False
    if na == nb:
        return True
    for grp in _CANONICAL_GROUPS:
        if na in grp and nb in grp:
            return True
    return False


def _row_correct(row, info, ground_truth_in_harness_set):
    """Compare pipeline's per-row eval_library to ground-truth annotation."""
    pipeline = row.get("eval_library", "")
    if ground_truth_in_harness_set:
        # Ground truth: this benchmark IS run with info["harness_annotation"].
        # Strict match required — including custom fork names. A canonical
        # equivalent of the parent library (e.g. "lm-evaluation-harness")
        # is NOT acceptable when the paper names a distinct fork.
        return "TRUE" if _same_library(pipeline, info["harness_annotation"]) else "FALSE"
    else:
        # Ground truth: this benchmark is NOT run with the named harness.
        # Pipeline must abstain.
        return "TRUE" if _is_blank(pipeline) else "FALSE"


def fill_with(path):
    rows = read_csv(path)
    fieldnames = list(rows[0].keys()) if rows else []
    n_true = 0
    per_paper = {}
    for r in rows:
        pf = r["paper_folder"]
        bm = r["benchmark"]
        info = PAPER_INFO.get(pf)
        if info is None:
            continue
        in_harness = bm in info["harness_benchmarks"]
        correct = _row_correct(r, info, in_harness)
        if in_harness:
            r["annotation"]      = info["harness_annotation"]
            base_note            = info["harness_note"]
        else:
            r["annotation"]      = "unknown"
            base_note            = info["non_harness_note"]
        r["annotator_notes"] = f"{base_note} {correct}."
        r["correct"] = correct
        if correct == "TRUE":
            n_true += 1
        per_paper.setdefault(pf, [0, 0])
        per_paper[pf][1] += 1
        if correct == "TRUE":
            per_paper[pf][0] += 1
    with open(path, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames, quoting=csv.QUOTE_NONNUMERIC)
        w.writeheader()
        for r in rows:
            w.writerow(r)
    print(f"  {os.path.basename(path)}: {n_true}/{len(rows)} = "
          f"{100*n_true/len(rows):.1f}%")
    for pf, (t, n) in sorted(per_paper.items()):
        print(f"    {pf[:55]:<55}  {t:>3}/{n:<3}  =  {100*t/n:>5.1f}%")


def fill_without(path):
    rows = read_csv(path)
    fieldnames = list(rows[0].keys()) if rows else []
    n_true = 0
    for r in rows:
        pf = r["paper_folder"]
        if pf in PAPER_ANNOT_WITHOUT:
            annot, base_note = PAPER_ANNOT_WITHOUT[pf]
            # WITHOUT-pool correct flag: pipeline must abstain (unknown/null)
            correct = "TRUE" if _is_blank(r.get("eval_library", "")) else "FALSE"
            r["annotation"]      = annot
            r["annotator_notes"] = f"{base_note} {correct}."
            r["correct"]         = correct
            if correct == "TRUE":
                n_true += 1
    with open(path, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames, quoting=csv.QUOTE_NONNUMERIC)
        w.writeheader()
        for r in rows:
            w.writerow(r)
    print(f"  {os.path.basename(path)}: {n_true}/{len(rows)} = "
          f"{100*n_true/len(rows):.1f}%")


def main():
    print("WITH (per-benchmark strict):")
    fill_with(WITH_PATH)
    print()
    print("WITHOUT (paper-level):")
    fill_without(WITHOUT_PATH)


if __name__ == "__main__":
    main()
