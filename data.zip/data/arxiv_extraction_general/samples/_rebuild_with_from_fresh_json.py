"""
Regenerate annotation_eval_harness_WITH_v2.csv from the freshly-extracted
JSON folders. The patched extraction pipeline now writes per-benchmark
eval_library.name values into each JSON, so each CSV row inherits the
correct per-benchmark harness assignment.
"""

import csv
import json
import os

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_ROOT  = os.path.join(SCRIPT_DIR, "..", "llm")
WITH_PATH  = os.path.join(SCRIPT_DIR, "annotation_eval_harness_WITH_v2.csv")

PAPERS = [
    "BLOOM__A_176B-Parameter_Open-Access_Multilingual_Language_Model",
    "Llemma__An_Open_Language_Model_for_Mathematics",
    "Sheared_LLaMA__Accelerating_LM_Pre-training_via_Structured_Pruning",
    "Aya_23__Open_Weight_Releases_to_Further_Multilingual_Progress",
    "Nemotron-4_15B_Technical_Report",
]

FIELDS = ["row_id", "sample_set", "paper_folder", "arxiv_id",
          "paper_title", "model_name", "benchmark", "metric",
          "extracted_score", "normalized_score", "shots",
          "eval_library", "is_baseline", "json_file",
          "annotation", "annotator_notes", "correct"]


def emit_rows(paper_folder, start_id):
    out = []
    full = os.path.join(DATA_ROOT, paper_folder)
    next_id = start_id
    for root, _dirs, files in sorted(os.walk(full)):
        for fn in sorted(files):
            if not fn.endswith(".json"):
                continue
            p = os.path.join(root, fn)
            with open(p, "r", encoding="utf-8") as fh:
                d = json.load(fh)
            mi = d.get("model_info") or {}
            ev_list = d.get("evaluation_results") or []
            lib = (d.get("eval_library") or {}).get("name") or ""
            src = d.get("source_metadata") or {}
            ad  = src.get("additional_details") or {}
            arxiv_id    = ad.get("arxiv_id", "")
            paper_title = ad.get("paper_title", "")
            is_baseline = ad.get("is_baseline", "FALSE")
            for ev in ev_list:
                mc = ev.get("metric_config") or {}
                sd = ev.get("score_details") or {}
                gc = (ev.get("generation_config") or {})
                gen_args = gc.get("generation_args") or {}
                rel_json = os.path.relpath(p, os.path.join(SCRIPT_DIR, ".."))
                out.append({
                    "row_id":          str(next_id),
                    "sample_set":      "eval_harness_WITH",
                    "paper_folder":    paper_folder,
                    "arxiv_id":        arxiv_id,
                    "paper_title":     paper_title,
                    "model_name":      mi.get("name", ""),
                    "benchmark":       ev.get("evaluation_name", ""),
                    "metric":          mc.get("metric_name", ""),
                    "extracted_score": sd.get("score", ""),
                    "normalized_score":"",
                    "shots":           gen_args.get("shots", ""),
                    "eval_library":    lib,
                    "is_baseline":     is_baseline,
                    "json_file":       rel_json,
                    "annotation":      "",
                    "annotator_notes": "",
                    "correct":         "",
                })
                next_id += 1
    return out


def main():
    all_rows = []
    next_id = 10000
    print("Rebuilding WITH v2 CSV from fresh JSONs:")
    for paper in PAPERS:
        rows = emit_rows(paper, next_id)
        next_id += len(rows)
        # eval_library tally
        from collections import Counter
        lib_tally = Counter(r["eval_library"] for r in rows)
        print(f"  {paper[:55]:<55}  {len(rows)} rows  libs={dict(lib_tally)}")
        all_rows.extend(rows)

    with open(WITH_PATH, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS, quoting=csv.QUOTE_NONNUMERIC)
        w.writeheader()
        for r in all_rows:
            w.writerow(r)
    print(f"\nWrote {WITH_PATH}: {len(all_rows)} rows total")


if __name__ == "__main__":
    main()
