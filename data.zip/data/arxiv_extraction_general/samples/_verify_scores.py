"""
Re-verify the annotation_score_verification.csv by fetching each paper's ArXiv
HTML and checking whether each extracted_score appears in the paper text near
the corresponding model and benchmark names.

Outputs:
  - _html_cache/{arxiv_id}.html : cached HTML per paper
  - _verification_results.csv   : per-row verification result
  - stdout summary              : per-paper + overall %

Matching policy (designed to be conservative, not lenient):
  1. The extracted score must appear as a token in the page text in at least
     one of these forms:
       - exact string ("34.2")
       - float-normalised ("34.20", "34.200")
       - integer form if value is whole ("18" for 18.0)
       - decimal form scaled by 1/100 if value > 1 ("0.342" for 34.2)
  2. STRICT match: the score token must also appear within 2,000 characters
     of BOTH the model name AND the benchmark name (or a recognisable alias).
  3. LOOSE match: the score token appears anywhere in the document.
  Report both strict and loose pass rates.
"""

import csv
import html
import os
import re
import sys
import time
import urllib.error
import urllib.request
from collections import Counter, defaultdict

SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
CSV_PATH   = os.path.join(SCRIPT_DIR, "annotation_score_verification.csv")
CACHE_DIR  = os.path.join(SCRIPT_DIR, "_html_cache")
OUT_PATH   = os.path.join(SCRIPT_DIR, "_verification_results.csv")

# Map paper_folder → canonical arxiv ID (fix the few mis-padded ones)
ARXIV_OVERRIDES = {
    # CSV has "2312.0655" — truncated; full ID is 2312.06550
    "LLM360__Towards_Fully_Transparent_Open-Source_LLMs": "2312.06550",
    # 2603.03975 IS the correct ID for Phi-4-reasoning-vision (despite being a "future" 2026-03 ID)
}

# Benchmark name aliases — alternative names the paper may use for the same benchmark
BENCHMARK_ALIASES = {
    "HellaSwag":       ["HellaSwag", "hellaswag", "Hella-Swag", "Hella Swag"],
    "ARC-Easy":        ["ARC-E", "ARC Easy", "ARC-Easy", "arc_easy", "arc-easy"],
    "ARC-Challenge":   ["ARC-C", "ARC Challenge", "ARC-Challenge", "arc_challenge", "arc-challenge"],
    "MMLU":            ["MMLU", "mmlu"],
    "GSM8K":           ["GSM8K", "GSM-8K", "gsm8k", "GSM 8K"],
    "TriviaQA":        ["TriviaQA", "Trivia QA", "trivia_qa", "trivia-qa"],
    "PIQA":            ["PIQA", "piqa"],
    "SIQA":            ["SIQA", "siqa", "SocialIQA"],
    "OpenBookQA":      ["OpenBookQA", "OBQA", "openbookqa", "Open Book QA"],
    "WinoGrande":      ["WinoGrande", "winogrande", "Wino Grande"],
    "BoolQ":           ["BoolQ", "boolq"],
    "BBH":             ["BBH", "Big Bench Hard", "BigBench Hard", "BIG-Bench Hard"],
    "HumanEval":       ["HumanEval", "human_eval", "Human-Eval", "humaneval"],
    "MBPP":            ["MBPP", "mbpp"],
    "MATH":            ["MATH", "math"],
    "AGIEval":         ["AGIEval", "AGI Eval", "agieval"],
    "CommonsenseQA":   ["CommonsenseQA", "CSQA", "commonsense_qa"],
    "NaturalQuestions":["NaturalQuestions", "NQ", "Natural Questions", "natural_questions"],
    "Core":            ["Core", "core"],
    "Extended":        ["Extended", "extended"],
    "C4":              ["C4", "c4"],
    "Wikitext":        ["WikiText", "Wikitext", "wikitext", "WikiText-103"],
}


def arxiv_id(paper_folder, csv_id):
    return ARXIV_OVERRIDES.get(paper_folder, csv_id)


def fetch_html(aid, cache_dir):
    cache_path = os.path.join(cache_dir, f"{aid}.html")
    if os.path.exists(cache_path) and os.path.getsize(cache_path) > 1000:
        with open(cache_path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read(), True
    url = f"https://arxiv.org/html/{aid}"
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (verification-script)"})
    try:
        with urllib.request.urlopen(req, timeout=60) as r:
            raw = r.read().decode("utf-8", errors="ignore")
    except (urllib.error.HTTPError, urllib.error.URLError, TimeoutError) as e:
        print(f"  FAILED to fetch {url}: {e}", file=sys.stderr)
        return None, False
    with open(cache_path, "w", encoding="utf-8") as f:
        f.write(raw)
    return raw, False


_TAG_RE = re.compile(r"<[^>]+>")
_WS_RE  = re.compile(r"\s+")


def strip_html(s):
    s = _TAG_RE.sub(" ", s)
    s = html.unescape(s)
    s = _WS_RE.sub(" ", s)
    return s


def score_variants(extracted):
    """Return list of plausible string forms the score could appear as in text."""
    try:
        v = float(extracted)
    except (ValueError, TypeError):
        return []
    out = set()
    out.add(f"{v:g}")               # 34.2 → "34.2"; 18.0 → "18"
    out.add(f"{v:.1f}")             # "34.2"
    out.add(f"{v:.2f}")             # "34.20"
    out.add(f"{v:.3f}")             # "34.200"
    if v == int(v):
        out.add(str(int(v)))        # 18.0 → "18"
    if abs(v) > 1:
        d = v / 100
        out.add(f"{d:g}")           # 94 → "0.94", 34.2 → "0.342"
        out.add(f"{d:.2f}")         # 94 → "0.94"
        out.add(f"{d:.3f}")         # 34.2 → "0.342"
        out.add(f"{d:.4f}")
    # drop tokens shorter than 2 chars (would match anything)
    return [t for t in out if len(t) >= 2]


def find_score_positions(text, score):
    """Find all character offsets where any score variant appears as a number token."""
    positions = []
    for v in score_variants(score):
        # surround with non-digit boundary to avoid e.g. "18" matching "118"
        pat = re.compile(r"(?<![\d.])" + re.escape(v) + r"(?![\d.])")
        for m in pat.finditer(text):
            positions.append((m.start(), v))
    return positions


def find_name_positions(text, name):
    """Find all offsets where a name (model or benchmark, exact or fuzzy) appears."""
    positions = []
    # exact case-insensitive
    pat = re.compile(re.escape(name), re.IGNORECASE)
    for m in pat.finditer(text):
        positions.append(m.start())
    return positions


def benchmark_token_positions(text, benchmark):
    """Try all aliases for the benchmark."""
    candidates = BENCHMARK_ALIASES.get(benchmark, [benchmark])
    if benchmark not in candidates:
        candidates = [benchmark] + list(candidates)
    positions = []
    for c in candidates:
        positions.extend(find_name_positions(text, c))
    return sorted(set(positions))


def model_token_positions(text, model):
    """Search for the model name; try the full string and a hyphen-relaxed version."""
    pos = find_name_positions(text, model)
    # relax: hyphens, underscores, spaces become equivalent
    relaxed = re.sub(r"[-_\s]+", lambda _m: r"[-_\s]+", re.escape(model))
    try:
        pat = re.compile(relaxed, re.IGNORECASE)
        for m in pat.finditer(text):
            pos.append(m.start())
    except re.error:
        pass
    return sorted(set(pos))


def _strip_parenthetical(s):
    """Drop parenthetical qualifiers like 'BELEBELE (Indonesian)' -> 'BELEBELE'."""
    return re.sub(r"\s*\([^)]*\)\s*", "", s).strip()


def _model_size_variants(s):
    """Handle OpenELM-0.27B -> OpenELM-270M -> OpenELM 0.27B etc."""
    out = {s}
    m = re.search(r"(.+?)[-_\s]?(\d+\.?\d*)\s*B$", s, re.IGNORECASE)
    if m:
        prefix, size = m.group(1), float(m.group(2))
        out.add(prefix)                              # bare prefix
        out.add(f"{prefix}-{int(round(size*1000))}M")  # 0.27B -> 270M
        out.add(f"{prefix} {size}B")
        out.add(f"{prefix}-{size}B")
    return [x for x in out if len(x) >= 3]


def verify_row(text, model, benchmark, score, proximity=3000):
    """Return (loose_ok, medium_ok, strict_ok) for this row.

    loose  : score value appears anywhere in the paper text
    medium : score appears within `proximity` chars of model OR benchmark
    strict : score appears within `proximity` chars of both model AND benchmark
    """
    score_pos = find_score_positions(text, score)
    if not score_pos:
        return (False, False, False)
    loose = True

    # try multiple model name variants
    model_pos = []
    for mv in _model_size_variants(model):
        model_pos.extend(model_token_positions(text, mv))
    model_pos = sorted(set(model_pos))

    # try benchmark stripped of parenthetical
    benchmark_variants = [benchmark, _strip_parenthetical(benchmark)]
    benchmark_pos = []
    for bv in benchmark_variants:
        if bv:
            benchmark_pos.extend(benchmark_token_positions(text, bv))
    benchmark_pos = sorted(set(benchmark_pos))

    near_model = False
    near_bench = False
    for sp, _v in score_pos:
        if any(abs(sp - mp) <= proximity for mp in model_pos):
            near_model = True
        if any(abs(sp - bp) <= proximity for bp in benchmark_pos):
            near_bench = True
        if near_model and near_bench:
            break

    medium = near_model or near_bench
    strict = near_model and near_bench
    return (loose, medium, strict)


def main():
    with open(CSV_PATH, "r", encoding="utf-8-sig") as f:
        rows = list(csv.DictReader(f))

    # group by paper
    by_paper = defaultdict(list)
    for r in rows:
        by_paper[r["paper_folder"]].append(r)

    print(f"Loaded {len(rows)} rows across {len(by_paper)} papers")
    print()

    # fetch all HTMLs first
    html_text = {}
    for paper, paper_rows in sorted(by_paper.items()):
        aid = arxiv_id(paper, paper_rows[0]["arxiv_id"])
        print(f"Fetching {aid} ({paper[:50]}, {len(paper_rows)} rows) ... ", end="", flush=True)
        raw, cached = fetch_html(aid, CACHE_DIR)
        if raw is None:
            print("FAILED")
            html_text[paper] = None
            continue
        txt = strip_html(raw)
        html_text[paper] = txt
        print(f"OK ({len(raw)//1024} kB, text {len(txt)//1024} kB, {'cached' if cached else 'fetched'})")
        if not cached:
            time.sleep(1.0)  # be polite to arxiv

    print()
    print("Verifying rows ...")

    # verify each row
    results = []
    per_paper = defaultdict(lambda: [0, 0, 0, 0])  # loose, medium, strict, total

    for r in rows:
        paper = r["paper_folder"]
        text  = html_text.get(paper)
        if text is None:
            results.append({**r, "loose_ok": "", "medium_ok": "", "strict_ok": "", "note": "HTML fetch failed"})
            continue
        try:
            score = float(r["extracted_score"])
        except ValueError:
            results.append({**r, "loose_ok": "", "medium_ok": "", "strict_ok": "", "note": "non-numeric"})
            continue
        model = r["model_name"].strip()
        benchmark = r["benchmark"].strip()
        loose, medium, strict = verify_row(text, model, benchmark, score)
        results.append({
            "row_id":          r["row_id"],
            "paper_folder":    paper,
            "arxiv_id":        r["arxiv_id"],
            "model_name":      model,
            "benchmark":       benchmark,
            "metric":          r["metric"],
            "extracted_score": r["extracted_score"],
            "loose_ok":        loose,
            "medium_ok":       medium,
            "strict_ok":       strict,
            "note":            "",
        })
        per_paper[paper][3] += 1
        if loose:  per_paper[paper][0] += 1
        if medium: per_paper[paper][1] += 1
        if strict: per_paper[paper][2] += 1

    # write per-row results
    with open(OUT_PATH, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=[
            "row_id", "paper_folder", "arxiv_id", "model_name", "benchmark",
            "metric", "extracted_score", "loose_ok", "medium_ok", "strict_ok", "note"
        ])
        w.writeheader()
        for r in results:
            w.writerow(r)

    # summary
    totals = [0, 0, 0, 0]
    print()
    print("=" * 110)
    print(f"{'paper':<55} {'loose':>14} {'medium':>14} {'strict':>14} {'rows':>5}")
    print("-" * 110)
    for paper in sorted(by_paper.keys()):
        l, m, s, n = per_paper[paper]
        if n == 0:
            print(f"{paper[:54]:<55} {'-- HTML fail --':>14} {'':>14} {'':>14} {len(by_paper[paper]):>5}")
            continue
        lp = f"{l}/{n} = {100*l/n:5.1f}%"
        mp = f"{m}/{n} = {100*m/n:5.1f}%"
        sp = f"{s}/{n} = {100*s/n:5.1f}%"
        print(f"{paper[:54]:<55} {lp:>14} {mp:>14} {sp:>14} {n:>5}")
        for i, v in enumerate([l, m, s, n]):
            totals[i] += v
    print("-" * 110)
    l, m, s, n = totals
    if n > 0:
        lp = f"{l}/{n} = {100*l/n:.2f}%"
        mp = f"{m}/{n} = {100*m/n:.2f}%"
        sp = f"{s}/{n} = {100*s/n:.2f}%"
        print(f"{'OVERALL':<55} {lp:>14} {mp:>14} {sp:>14} {n:>5}")
    print()
    print("Definitions:")
    print("  loose  : the score value appears as a number token anywhere in the paper text")
    print("  medium : the score appears within 3,000 chars of the model name OR the benchmark name")
    print("  strict : the score appears within 3,000 chars of both the model name AND the benchmark name")
    print()
    print(f"Per-row results written to: {OUT_PATH}")


if __name__ == "__main__":
    main()
